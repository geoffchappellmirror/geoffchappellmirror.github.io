
/*  ************************************************************************  *
 *				   memstrat.h				      *
 *  ************************************************************************  */

#ifndef __MEMSTRAT_H__
#define __MEMSTRAT_H__

#include    "standard.h"

/*  Functions for controlling memory strategies  */

WORD _dos_getstrategy (WORD *);
WORD _dos_getumblink (BOOL *);
WORD _dos_setstrategy (WORD);
WORD _dos_setumblink (BOOL);

/*  Allocation strategies  */

#define     FIRST_FIT	    0x00
#define     BEST_FIT	    0x01
#define     LAST_FIT	    0x02

#define     HIGHONLY	    0x40
#define     LOADHIGH	    0x80

/*  UMB Linkage  */

#define     NOUMBS	    0x0000	    // upper memory link disabled
#define     UMBS	    0x0001	    // upper memory link enabled

#endif	// ifndef __MEMSTRAT_H__

/*  ************************************************************************  */

