
/*  ************************************************************************  *
 *				   standard.h				      *
 *  ************************************************************************  */

#ifndef __STANDARD_H__
#define __STANDARD_H__

/*  Some generally helpful types  */

typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned long int DWORD;

typedef int BOOL;

/*  Some convenient symbols for logical operators and values  */

#define AND	&&
#define NOT	!
#define OR	||

#define FALSE	0
#define TRUE	1	// NOT FALSE

#endif	// ifndef __STANDARD_H__

/*  ************************************************************************  */

